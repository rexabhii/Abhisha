const q = {
  text: "Pick the thing you love most",
  choices: ["Watching movies with me","My terrible jokes","My cooking experiments","Holding my hand"],
  scoring: [25,25,25,25]
};
const questionEl = document.getElementById('question');
const choicesEl = document.getElementById('choices');
const resultEl = document.getElementById('result');
const restart = document.getElementById('restart');
let score = 0;
function render(){
  questionEl.textContent = q.text;
  choicesEl.innerHTML = '';
  q.choices.forEach((c,i)=>{
    const btn = document.createElement('button');
    btn.className = 'choice';
    btn.textContent = c;
    btn.addEventListener('click', ()=>{
      score += q.scoring[i];
      resultEl.classList.remove('hidden');
      resultEl.textContent = `You scored ${score}! Final verdict: You're 100% my favourite person 😄`;
      restart.classList.remove('hidden');
    });
    choicesEl.appendChild(btn);
  });
}
restart.addEventListener('click', ()=> location.reload());
render();
