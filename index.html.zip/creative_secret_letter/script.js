const bank = document.getElementById('bank');
const letter = document.getElementById('letter');
const secret = 'secret';
bank.addEventListener('click', (e)=>{
  if(e.target.tagName !== 'BUTTON') return;
  const word = e.target.textContent.trim().toLowerCase();
  if(word === secret){
    letter.classList.remove('hidden');
    letter.setAttribute('aria-hidden','false');
  } else {
    e.target.animate([{transform:'scale(1)'},{transform:'scale(.95)'},{transform:'scale(1)'}],{duration:180});
  }
});
