const canvas = document.getElementById('sky');
const ctx = canvas.getContext('2d');
function resize(){canvas.width = innerWidth; canvas.height = innerHeight; draw();}
window.addEventListener('resize', resize);
const stars = [];
const messages = [
  "I remember our first laugh.",
  "You make ordinary moments magical.",
  "Thank you for being you.",
  "With you, time feels gentle."
];
for(let i=0;i<40;i++){
  stars.push({x:Math.random()*innerWidth, y:Math.random()*innerHeight, r:1+Math.random()*2, msg: messages[i % messages.length]});
}
function draw(){
  ctx.clearRect(0,0,canvas.width,canvas.height);
  // background gradient
  const g = ctx.createLinearGradient(0,0,0,canvas.height);
  g.addColorStop(0,'#021027'); g.addColorStop(1,'#02030b');
  ctx.fillStyle = g; ctx.fillRect(0,0,canvas.width,canvas.height);
  // draw stars
  stars.forEach(s=>{
    ctx.beginPath(); ctx.arc(s.x,s.y,s.r,0,Math.PI*2); ctx.fillStyle = 'white'; ctx.fill();
  });
}
function getHoveredStar(mx,my){
  return stars.find(s=> Math.hypot(s.x-mx,s.y-my) < 8 );
}
canvas.addEventListener('click',(e)=>{
  const rect = canvas.getBoundingClientRect();
  const mx = e.clientX - rect.left, my = e.clientY - rect.top;
  const star = getHoveredStar(mx,my);
  const note = document.getElementById('note');
  if(star){
    note.classList.remove('hidden');
    note.textContent = star.msg;
  } else {
    note.classList.add('hidden');
  }
});
resize();
