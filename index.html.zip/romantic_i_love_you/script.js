const heart = document.getElementById('heart');
const reasonsEl = document.getElementById('reasons');
const list = document.getElementById('list');
const finalBtn = document.getElementById('final');
const popup = document.getElementById('popup');
const close = document.getElementById('close');
const headline = document.getElementById('headline');
const reasons = [
  "You listen when I need to talk.",
  "You laugh at the small things.",
  "You inspire me to be better.",
  "Your smile brightens my day.",
  "I love the way you think."
];
let shown = 0;
// initial simulated loading
setTimeout(()=> headline.textContent = "A small surprise for you...", 1200);
heart.addEventListener('click', ()=>{
  reasonsEl.classList.remove('hidden');
  if (shown < reasons.length){
    const li = document.createElement('li');
    li.textContent = reasons[shown++];
    list.appendChild(li);
  }
});
finalBtn.addEventListener('click', ()=>{
  popup.classList.remove('hidden');
});
close.addEventListener('click', ()=> popup.classList.add('hidden'));
